
print("Hola bienvenido,")
print("que operacion deseas hacer")



print("(1) sumar")
print("(2) restar")
print("(3) multiplicar")
print("(4) dividir")

opcion = input()

print("increse su primer numero")
num_1 = float(input())

print("Increse su segundo nuemero")
num_2 = float(input())

if opcion == 1:
    resultado_1 = (num_1 + num_2)
    print ("el resultado es:"), resultado_1
elif opcion == 2:
    resultado_2 = (num_1 - num_2)
    print ("el resultado es:"), resultado_2
elif opcion == 3:
    resultado_3 = (num_1 * num_2)
    print ("el resultado es:"), resultado_3
elif opcion == 4:
    resultado_4 = (num_1 / num_2)
    print ("el resultado es:"), resultado_4
    
    
